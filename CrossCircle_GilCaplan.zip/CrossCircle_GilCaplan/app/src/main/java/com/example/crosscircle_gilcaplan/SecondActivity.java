package com.example.crosscircle_gilcaplan;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {
    private Button return1;
    private TextView winner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        return1=findViewById(R.id.return1);
        winner=findViewById(R.id.winner);
        return1.setOnClickListener(this);
        Intent intent=getIntent();
        if(intent.getIntExtra("winner",-1)==-1) { winner.setText("TIE"); }
        else if(intent.getIntExtra("winner",1)==1){winner.setText("PlayerX won");}
        else if(intent.getIntExtra("winner",0)==0){winner.setText("Player0 won");}
    }

    @Override
    public void onClick(View v) {
        setResult(RESULT_OK);
        finish();
    }
}